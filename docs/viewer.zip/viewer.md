# DomiNyan Viewer

<!-- 第一行：Game + Snapshot + Turn/Player/Phase + Tabs -->

<div style="display: flex; flex-wrap: wrap; align-items: center; gap: 1rem; margin-bottom: 0.5rem;">

  <!-- Game + Snapshot -->
  <div style="display: flex; gap: 1rem;">
    <div style="display: flex; flex-direction: column; font-size: 0.9rem;">
      **Game**  
      <select id="gameSelect" style="min-width:120px;"></select>
    </div>
    <div style="display: flex; flex-direction: column; font-size: 0.9rem;">
      **Snapshot**  
      <select id="snapshotSelect" style="min-width:120px;"></select>
    </div>
  </div>

  <!-- Filter (Turn/Player/Phase) -->
  <div style="display: flex; gap: 1rem; margin-left: 1rem;">
    <div style="display: flex; flex-direction: column; font-size: 0.9rem;">
      *Turn*  
      <select id="turnFilter" style="width:80px;"></select>
    </div>
    <div style="display: flex; flex-direction: column; font-size: 0.9rem;">
      *Player*  
      <select id="playerFilter" style="width:80px;"></select>
    </div>
    <div style="display: flex; flex-direction: column; font-size: 0.9rem;">
      *Phase*  
      <select id="phaseFilter" style="width:80px;"></select>
    </div>
  </div>

  <!-- Tabs (Snapshot/Players/Chart/Supply) -->
  <div style="display: flex; gap: 0.5rem; margin-left: auto;">
    <button class="md-button tab-button" data-tab="snapshot">Snapshot JSON</button>
    <button class="md-button tab-button" data-tab="players">Players</button>
    <button class="md-button tab-button" data-tab="chart">Chart</button>
    <button class="md-button tab-button" data-tab="supply">Supply</button>
  </div>

</div>

<!-- 第二行：Metrics (只在chart时可见 -> index.js控制 display) -->
<div id="metricsPanel" style="margin-bottom: 0.5rem; display: none;">
  **Metrics**  
  <label><input type="checkbox" data-metric="coin" checked> Coin</label>
  <label><input type="checkbox" data-metric="action" checked> Action</label>
  <label><input type="checkbox" data-metric="buy" checked> Buy</label>
  <label><input type="checkbox" data-metric="hand"> Hand</label>
  <label><input type="checkbox" data-metric="deck"> Deck</label>
  <label><input type="checkbox" data-metric="discard"> Discard</label>
  <label><input type="checkbox" data-metric="played"> Played</label>
</div>

<!-- 第三行：Tab Content -->
<div>
  <div id="tab-snapshot" class="tab-content md-card md-shadow--2dp" style="padding:1rem; display:none;"></div>
  <div id="tab-players"  class="tab-content md-card md-shadow--2dp" style="padding:1rem; display:none;"></div>
  <div id="tab-chart"    class="tab-content md-card md-shadow--2dp" style="padding:1rem; display:none;">
    <p>(Chart Placeholder...)</p>
  </div>
  <div id="tab-supply"   class="tab-content md-card md-shadow--2dp" style="padding:1rem; display:none;">
    <p>(Supply Placeholder...)</p>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script type="module" src="/js/viewer/index.js"></script>