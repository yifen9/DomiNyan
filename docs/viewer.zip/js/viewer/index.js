// index.js

import { fetchReplaysIndex, fetchTrackerIndex, fetchSnapshotData } from './loader.js';
import { renderPlayers, renderSnapshotRaw, renderSupplyAndTrash } from './render.js';
import { renderResourceChart } from './chart.js';

const trackerCache = new Map();  
let allTrackerEntries = [];
let currentFiltered = [];

/**
 * 读取勾选的 metrics（coin, action, buy, deck, hand, discard, played）
 */
function getActiveMetrics() {
  const toggles = document.querySelectorAll('#metricsToggles input[type="checkbox"]');
  const active = [];
  toggles.forEach(chk => {
    if (chk.checked) {
      active.push(chk.dataset.metric);
    }
  });
  return active;
}

/**
 * 应用当前 Filter (turn/player/phase) 并刷新图表
 */
function applyFilters() {
  const folder = document.getElementById("gameSelect").value;
  const turnVal   = document.getElementById("turnFilter").value;
  const playerVal = document.getElementById("playerFilter").value;
  const phaseVal  = document.getElementById("phaseFilter").value;

  if (!folder) return;

  // 筛选
  currentFiltered = allTrackerEntries.filter(e => {
    return (!turnVal   || e.turn   == turnVal) &&
           (!playerVal || e.player == playerVal) &&
           (!phaseVal  || e.phase  == phaseVal);
  });

  // 更新 snapshot 下拉
  renderSnapshotOptions(currentFiltered);

  // 重新绘图
  const activeMetrics = getActiveMetrics();
  renderResourceChart(currentFiltered, folder, activeMetrics);
}

/**
 * 更新 turn/player/phase 下拉框
 */
function renderFilters(trackerList) {
  const turnFilter   = document.getElementById("turnFilter");
  const playerFilter = document.getElementById("playerFilter");
  const phaseFilter  = document.getElementById("phaseFilter");

  const uniqueTurns   = [...new Set(trackerList.map(e => e.turn))].sort((a,b)=>a-b);
  const uniquePlayers = [...new Set(trackerList.map(e => e.player))].sort((a,b)=>a-b);
  const uniquePhases  = [...new Set(trackerList.map(e => e.phase))];

  turnFilter.innerHTML   = `<option value="">All</option>`;
  playerFilter.innerHTML = `<option value="">All</option>`;
  phaseFilter.innerHTML  = `<option value="">All</option>`;

  uniqueTurns.forEach(t => {
    turnFilter.innerHTML += `<option value="${t}">${t}</option>`;
  });
  uniquePlayers.forEach(p => {
    playerFilter.innerHTML += `<option value="${p}">P${p}</option>`;
  });
  uniquePhases.forEach(ph => {
    phaseFilter.innerHTML += `<option value="${ph}">${ph}</option>`;
  });
}

/**
 * 更新 snapshot 下拉框
 */
function renderSnapshotOptions(trackerList) {
  const snapshotSelect = document.getElementById("snapshotSelect");
  const folder = document.getElementById("gameSelect").value;
  const turnVal   = document.getElementById("turnFilter").value;
  const playerVal = document.getElementById("playerFilter").value;
  const phaseVal  = document.getElementById("phaseFilter").value;

  const filtered = trackerList.filter(e => {
    return (!turnVal   || e.turn   == turnVal) &&
           (!playerVal || e.player == playerVal) &&
           (!phaseVal  || e.phase  == phaseVal);
  });

  snapshotSelect.innerHTML = "";
  filtered.forEach(entry => {
    const opt = document.createElement("option");
    opt.value = `/data/games/replays/${folder}/${entry.path}`;
    opt.textContent = `${entry.log_id} | Turn ${entry.turn} | P${entry.player} | ${entry.phase}`;
    snapshotSelect.appendChild(opt);
  });

  if (filtered.length > 0) {
    snapshotSelect.value = snapshotSelect.options[0].value;
    snapshotSelect.dispatchEvent(new Event("change"));
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  const gameSelect     = document.getElementById("gameSelect");
  const snapshotSelect = document.getElementById("snapshotSelect");
  const turnFilter     = document.getElementById("turnFilter");
  const playerFilter   = document.getElementById("playerFilter");
  const phaseFilter    = document.getElementById("phaseFilter");
  const metricsPanel   = document.getElementById("metricsPanel");

  // tab-content映射
  const tabMap = {
    snapshot: document.getElementById("tab-snapshot"),
    players:  document.getElementById("tab-players"),
    chart:    document.getElementById("tab-chart"),
    supply:   document.getElementById("tab-supply")
  };

  // 合并 Tab 切换监听
  document.querySelectorAll(".tab-button").forEach(btn => {
    btn.addEventListener("click", () => {
      const tab = btn.dataset.tab;

      // 显示/隐藏 tab 内容
      Object.entries(tabMap).forEach(([key, el]) => {
        el.style.display = (key === tab) ? "block" : "none";
      });

      // 如果是 chart tab => 显示 metrics
      if (tab === "chart") {
        metricsPanel.style.display = "block";
      } else {
        metricsPanel.style.display = "none";
      }
    });
  });

  try {
    // 加载 replays 列表
    const replays = await fetchReplaysIndex();
    replays.forEach(r => {
      const opt = document.createElement("option");
      opt.value = r.folder;
      opt.textContent = r.timestamp || r.folder;
      gameSelect.appendChild(opt);
    });

    // 切换游戏 => 加载 trackerIndex
    gameSelect.addEventListener("change", async () => {
      const folder = gameSelect.value;
      if (!folder) return;

      let trackerList;
      if (trackerCache.has(folder)) {
        trackerList = trackerCache.get(folder);
      } else {
        trackerList = await fetchTrackerIndex(folder);
        trackerCache.set(folder, trackerList);
      }

      allTrackerEntries = trackerList;
      renderFilters(trackerList);
      renderSnapshotOptions(trackerList);

      currentFiltered = trackerList;
      // 首次绘图
      const activeMetrics = getActiveMetrics();
      renderResourceChart(currentFiltered, folder, activeMetrics);
    });

    // 切换 snapshot => 加载详细
    snapshotSelect.addEventListener("change", async () => {
      const path = snapshotSelect.value;
      if (!path) return;
      try {
        const data = await fetchSnapshotData(path);
        renderPlayers(data.players || []);
        renderSnapshotRaw(data);
        renderSupplyAndTrash(data.game || {});
      } catch (err) {
        console.error("Failed to load snapshot data:", err);
      }
    });

    // Filter => 重新绘图
    [turnFilter, playerFilter, phaseFilter].forEach(sel => {
      sel.addEventListener("change", applyFilters);
    });

    // Metrics => 重新绘图
    document.querySelectorAll('#metricsToggles input[type="checkbox"]')
      .forEach(chk => {
        chk.addEventListener('change', applyFilters);
      });

    // 如果 replays 有数据 => 默认选第一个
    if (replays.length > 0) {
      gameSelect.value = replays[0].folder;
      gameSelect.dispatchEvent(new Event("change"));
    }

  } catch (err) {
    console.error("Initialization error:", err);
  }
});