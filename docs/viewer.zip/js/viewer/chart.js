import { fetchSnapshotData } from "./loader.js";

let chartInstance = null;

function generatePalette(count) {
  const colors = [];
  for (let i = 0; i < count; i++) {
    const hue = (360 * i) / count;
    // 修正：使用模板字符串
    colors.push(`hsl(${hue}, 70%, 50%)`);
  }
  return colors;
}

function buildDataset(label, dataArr) {
  return {
    label,
    data: dataArr,
    borderColor: "#aaa",
    backgroundColor: "transparent",
    fill: false,
    borderDash: [],
    pointRadius: 0,
    pointHoverRadius: 5,
    tension: 0.2
  };
}

export async function renderResourceChart(trackerData, folder, activeMetrics) {
  const container = document.getElementById("tab-chart");
  if (!container) return;

  container.innerHTML = "";
  if (chartInstance) {
    chartInstance.destroy();
    chartInstance = null;
  }
  if (!trackerData || trackerData.length === 0) {
    return;
  }

  // 修正：反引号包裹
  const snapshots = await Promise.all(
    trackerData.map(entry => {
      const path = `/data/games/replays/${folder}/${entry.path}`;
      return fetchSnapshotData(path).then(json => ({
        log_id: entry.log_id,
        snapshot: json
      }));
    })
  );

  const playerMap = new Map();
  const playerIds = [...new Set(trackerData.map(e => e.player))].sort((a, b) => a - b);
  playerIds.forEach(pid => playerMap.set(pid, []));

  snapshots.forEach(({ log_id, snapshot }) => {
    if (!snapshot.players || snapshot.players.length === 0) {
      return; 
    }
    snapshot.players.forEach(p => {
      if (!playerMap.has(p.id)) return;
      playerMap.get(p.id).push({
        log_id,
        coin:   p.coin,
        action: p.action,
        buy:    p.buy,
        deck:    p.deck     ? p.deck.length     : 0,
        hand:    p.hand     ? p.hand.length     : 0,
        discard: p.discard  ? p.discard.length  : 0,
        played:  p.played   ? p.played.length   : 0
      });
    });
  });

  let allDatasets = [];
  playerIds.forEach(pid => {
    const arr = playerMap.get(pid);
    if (!arr || arr.length === 0) return;
    arr.sort((a, b) => a.log_id - b.log_id);

    activeMetrics.forEach(metric => {
      const dataPoints = arr.map(e => ({
        x: e.log_id,
        y: e[metric] || 0
      }));
      const label = `P${pid} ${metric[0].toUpperCase() + metric.slice(1)}`;
      allDatasets.push(buildDataset(label, dataPoints));
    });
  });

  if (allDatasets.length === 0) {
    return;
  }

  const palette = generatePalette(allDatasets.length);
  allDatasets.forEach((ds, i) => {
    ds.borderColor = palette[i];
  });

  const canvas = document.createElement("canvas");
  container.appendChild(canvas);

  const ctx = canvas.getContext("2d");
  chartInstance = new Chart(ctx, {
    type: "line",
    data: { datasets: allDatasets },
    options: {
      responsive: true,
      plugins: {
        title: { display: true, text: "Player Resource Timeline" },
        legend: {
          position: 'bottom',
          labels: {
            boxWidth: 30,
            boxHeight: 2,
            color: "#333",
            font: { size: 14 },
            padding: 10
          }
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      },
      interaction: {
        mode: 'nearest',
        axis: 'x',
        intersect: false
      },
      scales: {
        x: {
          type: "linear",
          title: { display: true, text: "Log ID" }
        },
        y: {
          title: { display: true, text: "Resource Value" }
        }
      }
    }
  });
}